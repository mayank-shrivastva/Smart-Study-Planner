<?php
if(isset($_GET['dte'])){
	$date = $_GET['dte'];
}
if(isset($_POST['submit'])){
$name = $_POST['name'];
$email = $_POST['email'];
$mysqli = new mysqli('localhost', 'root', '', 'bookingcalendar');
$stmt = $mysqli->prepare("INSERT INTO bookings (name, email, date) VALUES (?,?,?)");
$stmt->bind_param('sss', $name, $email, $date);
$stmt->execute();
$msg = "<div class='alert alert-success'>Booking Successfull</div>";
$stmt->close();
$mysqli->close();
}



?>


<!DOCTYPE html>
<html>
<body>
<div class="container">
<h1 class="text-center">Book for Date:<?php echo date('d/m/Y' ,strtotime($date)) ?> </h1><hr>
<div class="row">
<div class="col-md-6 col-md-offset-3">
<?php echo isset($msg)?$msg:'';?>
<form action="" method="post" autocomplete="off">
<div class="form-group">
<label for="">Name</label>
<input type="text" class="form-control" name="name">
</div>
<div class="form-group">
<label for="">Email</label>
<input type="email" class="form-control" name="email">
</div>
<button class="btn btn-primary" type="submit" name="submit">Submit</button>
</form>
</div>
</div>
</div>


</body>
</html>

